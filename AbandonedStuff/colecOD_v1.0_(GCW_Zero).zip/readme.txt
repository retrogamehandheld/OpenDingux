ColecOD V1.0
--------------------------------------------------------------------------------
This is a ColecoVision emulator for the GCW-ZERO.
To use this emulator, you must have compatibles ROMS with .COL/.ROM/.BIN extension.
Do not ask me about ROMS, I don't have them. A search with Google will certainly help 
you.

Features :
----------
 Most things you should expect from an emulator.

Missing :
---------
 All that is not yet emulated ;)

Check updates on my web site : 
http://www.portabledev.com

--------------------------------------------------------------------------------
List of emulated games
--------------------------------------------------------------------------------
Most of the colecovision games ;)

-------------------------------------------------------------------------------
History :
--------------------------------------------------------------------------------
V1.0 : 15/06/2013
  Initiale release

--------------------------------------------------------------------------------
How to use ColecOD :
--------------------------------------------------------------------------------
Put ColecOD.opk in your apps directory. Put your games where you want.
Reboot menu, the colecOD icon will appear in Emulators section.

Controls (both Player 1 and 2) :
 * Direction pad and A / B : Coleco pad and button 1 / 2
 * START is the same that the #1 KEYPAD
 * SELECT is the same that the #2 KEYPAD
 * X is the same than the #3 KEYPAD
 * Y is the same than the #4 KEYPAD
 * R is the same than the #* KEYPAD
 * L is the same than the ## KEYPAD
 
You can also click on START + SELECT to enter the menu.

--------------------------------------------------------------------------------
Credits
--------------------------------------------------------------------------------
Special thanks to :
  Daniel Bienvenue (http://newcoleco.dev-fr.org) for information about tms9918a 
  chipset.
  mess authors (http://www.mess.org) for information about colecovision and sn76489a
  sound chip.
  Marat Fayzullin (http://fms.komkon.org/ColEm/) for information about tms9918a.
  QbertAddict for tests.
Without the help of the infos from these people, this emulator can't be here.
--------------------------------------------------------------------------------
Alekmaul
alekmaul@portabledev.com
http://www.portabledev.com
--------------------------------------------------------------------------------

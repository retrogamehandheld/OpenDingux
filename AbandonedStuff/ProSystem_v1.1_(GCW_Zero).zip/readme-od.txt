ProSystem for GCW0 V1.1
--------------------------------------------------------------------------------
This is a port of ProSystem, an Atari 7800 for GCW-ZERO.
To use this emulator, you must have compatibles ROMS with .a78/.bin extension.
You also need the 7800.rom rom bios to use it. But it is not mandatory, the emulator
can work without it. A quick search on atariage website will help you about that ;-)
Do not ask me about ROMS, I don't have them. A search with Google will certainly help 
you.

Features :
----------
 Most things you should expect from an emulator.

Missing :
---------
 Just tell me :).

Check updates on my web site : 
http://www.portabledev.com

--------------------------------------------------------------------------------
List of emulated games
--------------------------------------------------------------------------------
Lots of the atari 7800 games ;)

--------------------------------------------------------------------------------
History :
--------------------------------------------------------------------------------
V1.1 : 16/06/2013
  Fix bug with uppercase/lowercase names
  Save current rom directory
  Clean up makefile
  Add ring buffer for sound
  
V1.0 : 01/10/2012
  Initiale release

--------------------------------------------------------------------------------
How to use ProSystem :
--------------------------------------------------------------------------------
Put prosystem.opk to "apps" folder of inner flash-memory of your handheld.
If you've got it, put bios named 7800.rom to "/boot/local/home" directory
Put your .a78 & .BIN games where you want.

Controls (both Player 1 and 2) :
 * Direction pad and A / B : Atari pad and button 1 / 2
 * START is the same that the PAUSE button
 * SELECT is the same that the SELECT button
 * X is the same than the RESET button
 * Y is the same than the RESET button
 * R is the same than the Left Difficulty button
 * L is the same than the Right Difficulty button
 
You can also click on START + SELECT to enter the menu.

Use START + SELECT to enter menu. 

--------------------------------------------------------------------------------
Credits
--------------------------------------------------------------------------------
Special thanks to :
  Greg Stanton for ProSystem source code (https://home.comcast.net/~gscottstanton/)
   an Atari 7800 emulator.
  zx81 (http://zx81.zx81.free.fr/serendipity_fr/) for PSP A7800 version (that helped
   me a lot to understand ProSystem).
  raz0red (http://www.twitchasylum.com/forum/viewtopic.php?t=519) for WII7800  (that
  helped me a lot to fix some timing problem).
  d_smargin for handy_a320 gui, which i used some part of code for prosystem gui.
  qbertaddict for test and video of prosystem.
Without the help of the infos from these people, this emulator can't be here.
--------------------------------------------------------------------------------
Alekmaul
alekmaul@portabledev.com
http://www.portabledev.com
--------------------------------------------------------------------------------
